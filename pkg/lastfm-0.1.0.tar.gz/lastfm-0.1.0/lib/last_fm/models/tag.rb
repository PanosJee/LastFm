module LastFm
  class Tag < Base
  end
end
