module LastFm
  class Chart < Base
  end
end