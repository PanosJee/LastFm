module LastFm
  class Event < Base
    
  end
end